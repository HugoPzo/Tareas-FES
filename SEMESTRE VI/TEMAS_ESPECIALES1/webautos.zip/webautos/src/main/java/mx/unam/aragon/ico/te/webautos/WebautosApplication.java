package mx.unam.aragon.ico.te.webautos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebautosApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebautosApplication.class, args);
	}

}
