package mx.unam.aragon.ico.te.webautos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebautosApplicationTests {

	@Test
	void contextLoads() {
	}

}
